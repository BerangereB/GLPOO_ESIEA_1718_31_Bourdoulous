package options;

import frames.OptionsJFrame;

public enum LANGUAGE {
	BACK("Back", "Retour"), 
	GENERATE_FRACTAL("Generate drawing with ", "Générer un dessin avec "), 
	REGENERATE("Regenerate","Regénérer"),
	GENERATE("Generate","Générer"),
	CANCEL("Cancel", "Annuler"),
	PLAY("Play", "Jouer"),
	LANGUE("Language :", "Langue :"),
	WELCOME(" WELCOME", "BIENVENUE"),
	FILE("File", "Fichier"),
	SAVE("Save","Sauvegarder"),
	QUIT("Quit","Quitter"),
	FN("Please enter the frame's name","Veuillez entrer le nom de l'image"),
	REINIT("Reinitialize","Réinitialiser"),
	RANDDRAW("Random draw","Tirage aléatoire"),
	SELECTEDDRAW("Personalized draw","Tirage personnalisé"),
	CSVDRAW("CSV draw","Tirage CSV"),
	FRACGEN("Fractale generator","Générateur de fractales"),
	CREDITS("Credits","Crédits"),
	GI("Graphic interface :","Interface graphique :"),
	FRACT("Fractales/Drawing :","Fractales/Dessins :"),
	TEST("Tests :","Tests :"),
	BONUS("Bonus/Puzzle :","Bonus/Puzzle"),
	STATS("Statistics :","Statistiques :");
	
	
	private String english;
	
	private String french;

	private LANGUAGE(String english, String french) {
		this.english = english;
		this.french = french;
	}
	
	public String getEnglish() {
		return english;
	}
	
	public String getFrench() {
		return french;
	}
	
	public String getSelectedLanguage() {
		if(OptionsJFrame.languageSelected == 0) {
			return french;
		}
		else if(OptionsJFrame.languageSelected == 1) {
			return english;
		}
		else return null;
		
	}
}
