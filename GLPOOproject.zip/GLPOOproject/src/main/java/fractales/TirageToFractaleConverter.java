package fractales;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import dao.Tirage;

public class TirageToFractaleConverter {
	private int p; // => b1
	private int q; // => b2
	private int a2;
	private float estompage; // => e1
	private int echelle; // b3
	private float couleur; // => b4
	private int a3; // pas de boule
	private String typeFractale;

	private List<Tirage> tirages;
	private Logger LOGGER = Logger.getLogger(TirageToFractaleConverter.class);

	public TirageToFractaleConverter(List<Tirage> tirages, String typeFractale) {
		this.tirages = tirages;
		this.typeFractale = typeFractale;

	}

	/**
	 * Convertit une liste de tirages en une liste de fractales
	 * 
	 */
	public List<Fractale> convertTirageToFractale() {

		List<Fractale> fractales = new ArrayList<Fractale>();
		for (Tirage tirage : tirages) {
			convertTirageToParamFractale(tirage.getB1(), tirage.getB2(), tirage.getB3(), tirage.getB4(), 0,
					tirage.getE1(), 10);
			Fractale fractale = getFractale();
			fractales.add(fractale);
		}
		LOGGER.info("Conversion tirages to fractales succeeded");
		return fractales;
	}

	/**
	 * Convertit les valeurs des boules et etoiles d'un tirage en paramètres d'une
	 * fractale => unicité
	 */
	private void convertTirageToParamFractale(int b1, int b2, int b3, int b4, int b5, int e1, int e2) {
		p = Math.min(b1, b2);
		q = Math.max(b1, b2);

		echelle = 20*b3;
		couleur = (float) b4 / 50;
		a3 = b5;

		estompage = (float) e1 + 2;

		a2 = e2;

	}

	/*
	 * Renvoie une fractale de type Julia, mandelbrot ou autre en fonction du type
	 * choisi par l'utilisateur
	 */
	private Fractale getFractale() {

		if (typeFractale.equals("Julia")) {

			/**
			 * FORMULE pour avoir les coordonnées du centre du bulb p/q de l'ensemble de
			 * Mandelbrot
			 * 
			 * On note Z = exp(2*PI*i*p/q) alors
			 * 
			 * Bulb(p/q) = Z/2 * (1 - Z/2)
			 * 
			 * Re_C = Re( Bulb(p/q) ) | Im_C = Im( Bulb(p/q) )
			 * 
			 */

			float Re_C = (float) ((float) ((float) 1 / 2 * Math.cos((float) 2 * Math.PI * p / q)
					- (float) 1 / 4 * Math.cos((float) 4 * Math.PI * p / q)));
			float Im_C = (float) ((float) ((float) 1 / 2 * Math.sin((float) 2 * Math.PI * p / q)
					- (float) 1 / 4 * Math.sin((float) 4 * Math.PI * p / q)));

			float X = (float) ((float) 1 / p * Math.cos((float) (2 * Math.PI * p / q))); // Léger décalage par rapport
																							// au centre du bulb
			a3/=50;
			JuliaFractale julia = new JuliaFractale(Re_C + a3*X, Im_C + a3*X, echelle, 1070, 540, estompage, couleur);
			
			return julia;
			
		} else if (typeFractale.equals("Newton")) {  
			
			return new NewtonFractal(p, q, a2, echelle, 1070, 540, estompage, couleur,a3);
			
		} else if (typeFractale.equals("Halley")) {  
			
			return new HalleyFractal(p, q, a2, echelle, 1070, 540, estompage, couleur,a3);
			
		} else {
			
			return new HouseHolder(p, q, a2, echelle, 1070, 540, estompage, couleur,a3);
			
		}
	}

}
